#!/bin/bash

GROUP_ID=$(ls -l /var/run/docker.sock | awk '{print $4}')
sudo groupadd -g ${GROUP_ID} docker
sudo usermod bluedata -G docker
