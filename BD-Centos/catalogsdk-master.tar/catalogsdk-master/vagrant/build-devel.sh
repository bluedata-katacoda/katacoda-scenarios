#! /bin/bash
# Launch packer in` background to start both virtualbox and ec2
VM_VERSION=1.0
NAS_IP=10.1.10.231
PACKER=$(which packer)
if [[ $? -eq 0 ]];
then
    ${PACKER} build -var "NAS_IP=${NAS_IP}" -var "VM_VERSION=${VM_VERSION}" --only=virtualbox-iso build.json
else
    echo "ERROR: packer binary not found."
    exit 2
fi
