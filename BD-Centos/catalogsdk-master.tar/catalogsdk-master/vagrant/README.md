## Vagratfile
- https://s3.amazonaws.com/bluedata-catalog/boxes/Vagrantfile

## Dependencies
- Vagrant version: 1.9.2 (https://www.vagrantup.com/downloads.html)
- VirtualBox version: 5.1.16 (https://www.virtualbox.org/wiki/Downloads)
