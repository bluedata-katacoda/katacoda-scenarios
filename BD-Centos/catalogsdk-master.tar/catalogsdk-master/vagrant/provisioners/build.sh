#!/bin/bash
set -e
set -x

# update root certs
curl -o /etc/pki/tls/certs/ca-bundle.crt http://curl.haxx.se/ca/cacert.pem
update-ca-trust force-enable

yum update -y
yum install -y http://dl.fedoraproject.org/pub/epel/6/i386/epel-release-6-8.noarch.rpm wget kernel-devel

# Remove requiretty, remove usedns and disable password login for ssh server
sed -i "s/^.*requiretty/#Defaults requiretty/" /etc/sudoers
sed -i "/UseDNS/d" /etc/ssh/sshd_config
echo "UseDNS no" >> /etc/ssh/sshd_config

echo 'Install vagrant user'
adduser vagrant
echo "vagrant ALL=(ALL) ALL" >> /etc/sudoers
echo "%vagrant ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers
echo 'Defaults env_keep+="SSH_AUTH_SOCK"' >> /etc/sudoers
# Installing the public vagrant key. when vagrant up is invoked
# for the first time (during provisioning phase), vagrant will
# change the public key to a locally generated key
echo 'Install vagrant SSH key'
mkdir -p ~vagrant/.ssh
# Copy the open public key from vagrant
wget https://raw.github.com/mitchellh/vagrant/master/keys/vagrant.pub -O ~vagrant/.ssh/authorized_keys
chown -R vagrant:vagrant ~vagrant/.ssh
chmod 0700 ~vagrant/.ssh
chmod 0600 ~vagrant/.ssh/authorized_keys

# Install necessary packages
yum install -y python-setuptools python-pip python-requests expect docker-io

# Add docker group as part of vagrant user
# Create docker group if doesn't exist already
getent group docker >/dev/null || groupadd -r docker

mkdir -p /var/lib/docker
chgrp -R docker /var/lib/docker
chmod 775 /var/lib/docker
chmod g+rwxs /var/lib/docker

usermod -a -G docker vagrant

chkconfig docker on
service docker start

mkdir -p /tmp/isomount
mount -t iso9660 -o loop /root/VBoxGuestAdditions.iso /tmp/isomount

echo "Installing Guest Additions"

# Install the drivers
/tmp/isomount/VBoxLinuxAdditions.run --nox11

# Cleanup
umount -f /tmp/isomount
rm -rf /tmp/isomount /root/VBoxGuestAdditions.iso

# Done with all the install. Clean up before packaging
# Ensure udev doesn't mess with the network
echo "Ensuring udev doesn't mess with the network..."
rm -f /etc/udev/rules.d/70-persistent-net.rules || true

sed -i 's/^HWADDR.*$//' /etc/sysconfig/network-scripts/ifcfg-eth0
sed -i 's/^UUID.*$//' /etc/sysconfig/network-scripts/ifcfg-eth0

rm -f /tmp/*.log
rm -f /tmp/*.sh

# Clean out all of the caching dirs
rm -rf /var/cache/* /usr/share/doc/*

# Clean up unused disk space so compressed image is smaller.
cat /dev/zero > /tmp/zero.fill || true
rm /tmp/zero.fill || true

history -c
sync && sync && sync
