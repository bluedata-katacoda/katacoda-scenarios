
### Developing CatalogSDK
1. Create your user accounts at https://pypi.python.org/pypi and https://testpypi.python.org/pypi
2. Give it@bluedata.com your username and ask them to add you as a "maintainer"
3. Execute the following:
    $ catalogsdk> python setup.py develop

That sets up your python environment so that the changes you make to your code
will automatically be reflected when you execute bdwb.

### Configuring PyPI
Create a '.pypirc' file which controls access to the PyPI servers.

```
$> cat << EOF >> ~/.pypirc
[distutils]
index-servers =
	pypi
	pypitest

[pypi]
repository=https://upload.pypi.org/legacy/
username=<USERNAME>
password=<PASSWORD>

[pypitest]
repository=https://test.pypi.org/legacy/
username=<USERNAME>
password=<PASSWORD>

EOF
```

### Pushing updates to PyPI
1. Update the version in bdworkbench/version.py. PyPI servers do not allow
   overwriting exiting versions.
2. First upload your changes to Test PyPI servers using the following:

```
$ catalogsdk> python setup.py sdist upload -r pypitest

```
3. Upgrade and test on a different server:
```
$>  pip install -i https://test.pypi.org/legacy/ --upgrade bdworkbench
```
4. When testing checks out, push to production PyPI:
```
$ catalogsdk> python setup.py sdist upload -r pypi

```

### SDK catalog entry
Ideally after every update to PyPI we should rebuild the catalog SDK app. But,
It's not strictly required as users can use pip to upgrade existing deployments
too.

1. Bump up the version in sdkapp.wb
2. Rebuild and publish the catalog bin file.
