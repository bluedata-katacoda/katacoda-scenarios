#!/usr/bin/env python
#
# Copyright (c) 2016 BlueData Software, Inc.
#
from __future__ import print_function

__version__ = "3.4"

if __name__ == "__main__":
    print("%s" % __version__, end='')
