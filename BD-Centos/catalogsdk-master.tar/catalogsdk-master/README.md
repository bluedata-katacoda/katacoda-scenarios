# BlueData EPIC App Workbench
Workbench for developing AppStore entries on BlueData EPIC platform.

## App Workbench
### Requirements
- Python 2.6.6 or greater. Python 3 is expected to work but untested.
- Docker 1.7, 1.12 and 1.13 are the supported docker versions on EPIC platforms.

### Workbench installation
```
   $> yum install -y python-pip # If pip is not already installed.
   $> pip install --upgrade pip # Ignore any python 2.6 warnings for now.
   $> pip install --upgrade setuptools
   $> pip install --upgrade bdworkbench
```

### Building a catalog entry for EPIC
Two completely opposite use cases are showcased here. The `beginner` developer
workflow assumes that the app is simple enough to not require any developer
intervention. While the `advanced` developer workflow assumes that all the
development happens outside the scope of the SDK and it is only used to create
the catalog bundles. The SDK itself is expected to be useful for all use cases
between these two extremes.


    NOTE: Before you try out any of these instruction, its important to uncomment
          'builder organization --name YOUR_ORGANIZATION_NAME' line and replace
          YOUR_ORGANIZATION_NAME with a valid organization name in each of the
          instruction files.


#### Beginner developer's workflow
These instructions illustrate the development process using Spark 1.6.0 as an
example. All the relevant files are available at https://github.com/bluedatainc/bluedata-catalog/tree/master/spark16.
And the instruction files is available at `samples/spark16_catalog_docker.wb`.

1. Create an empty directory and change into it: `mkdir devel && cd devel`
2. Initialize workbench: `bdwb --init`. This creates a few directories and
populates some starter code.

    ```
    $ devel> ls **
    appconfig:
    appjob  logging.sh  macros.sh  startscript  utils.sh

    image:
    ```
3. Author the docker files for each of the OS types you want to generate the
catalog bundles for. Currently `centos` and `rhel` are supported. For `centos`
the docker file must start with `FROM bluedata/centos6:latest`. For `rhel`
images the docker file must start with `FROM bluedata/rhel6:latest`. You are not
required to build both images but at least one must packaged into the catalog
bundle.

    ```
    $ deve/image> ls **
    centos:
    configure_services.sh  Dockerfile

    rhel:
    configure_services.sh  Dockerfile
    ```
4. Copy all the necessary files you want to include in the appconfig package
into the `appconfig` directory.

    ```
    $ devel/appconfig> ls
    appjob                hadoop             macros.sh            spark-env-aws.sh
    spark-master          zeppelin-env.sh    core-site-aws.xml    hive-site.xml
    merge-config.py       spark-env-docker.sh     spark-slave     zeppelin-log4j.properties
    core-site-docker.xml  hive-thriftserver  note.json            spark-env.sh
    startscript           zeppelin-server    core-site.xml        logging.sh
    spark-defaults.conf   spark-log4j.properties  utils.sh        zeppelin-site.xml
    ```
5. Create a workbench instruction file. For Spark 1.6.0 copy the instruction
file found in the samples directroy or get the latest on from the bluedata-catalog
repository.
6. Run the instructions. As we are building a RHEL image as well, you must to set
RHEL_USERNAME and RHEL_PASSWORD approriately before invoking the workbench. For
now these are the only two variable replacements supported in a Dockerfile.

    ```
    $ devel> chmod +x spark16_catalog_docker.wb
    $ devel> ./spark16_catalog_docker.wb
    ```
7. The end result of the last command is two catalog bundle files. All the
temporary artifacts generated during the catalog bundle build process are stored
in the `staging` directory: which may be deleted at any time without any side
effects.

    ```
    $ devel> ls
    appconfig  bdcatalog-centos-spark16-1.0.bin  bdcatalog-rhel-spark16-1.0.bin
    image      Logo_Spark.png                    spark16_catalog_docker.wb  staging
    ```

#### Advanced developer's workflow
This workflow assumes that all the components (appconfig, images, and entry
json file) are authored and/or built independently. The following instruction
file expects all the components to be in the current working directory.

    $> cat package.wb
    #!/usr/bin/env bdwb
    #
    # builder organization --name YOUR_ORGANIZATION_NAME

    catalog load --filepath spark16.json
    logo file --filepath Logo_Spark.png
    appconfig file --filepath spark16-v1.tgz

    image build --basedir image/centos --imgversion 1.0 --os centos
    catalog save --filepath spark16-centos.json --force
    catalog package --os centos

    image build --basedir image/rhel --imgversion 1.0 --os rhel
    catalog save --filepath spark16-rhel.json --force
    catalog package --os rhel

### Additional help
The workbench has built in help that give information about what various commands
do and the arguments they take.

    bdwb> help

    Documented commands (type help <topic>):
    ________________________________________
    EOF        builder  clusterconfig  help   logo  service
    appconfig  catalog  exit           image  role  workbench

    bdwb> help catalog
    usage: catalog [-h] {new,save,load,modify,package} ...

    Catalog entry management.

    optional arguments:
      -h, --help            show this help message and exit

    Subcommands:
      {new,save,load,modify,package}
        new                 Starts a session for creating a new catalog entry. Any
                            previouly started sessions will be lost unless they
                            were saved.
        save                Saves the current in-memory state of the catalog entry
                            to a file.
        load                Load an existing catalog entry.
        modify              Allows slected fields in the catalog entry to be
                            updated.
        package             Package all components of the catalog into a bundle
                            (.bin file).
    bdwb> help catalog new
    usage: catalog new [-h] --distroid DISTRO_ID --name NAME
                       [--depends_on DISTRO_ID] --desc DESCRIPTIOIN [-v VERSION]
                       [-c CATEGORIES [CATEGORIES ...]]
                       [--catalogapi CATALOG_API_VERSION]

    optional arguments:
      -h, --help            show this help message and exit
      --distroid DISTRO_ID  A BlueData catalog wide unique distro id. (default:
                            None)
      --name NAME           Catalog name for the end user. Enclose in double
                            quotes for names with spaces. (default: None)
      --depends_on DISTRO_ID
                            Distro id of another catalog this entry depends on.
                            This option is used to indicate that this is an add-on
                            catalog entry. (default: None)
      --desc DESCRIPTIOIN   Catalog description for the end user. Use double
                            quotes to enclose the description. (default: None)
      -v VERSION, --version VERSION
                            Catalog entry version of the form: MAJOR.MINOR
                            (default: 1.0)
      -c CATEGORIES [CATEGORIES ...], --categories CATEGORIES [CATEGORIES ...]
                            A space separated list of categories this entry will
                            be available under during cluster creation. Any
                            existing categories may be used or new one may also be
                            defined here. (default: Hadoop)
      --catalogapi CATALOG_API_VERSION
                            Catalog api version used by this entry. (default: 3)
    bdwb>
